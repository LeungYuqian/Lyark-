import React from 'react';
import { useTranslation } from 'react-i18next';
import { supabase } from '../lib/supabase';
import { Search, Copy, Filter } from 'lucide-react';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import toast from 'react-hot-toast';

interface ArkCode {
  id: string;
  title: string;
  code: string;
  category: string;
  subcategory: string;
}

export default function Dashboard() {
  const { t } = useTranslation();
  const [codes, setCodes] = React.useState<ArkCode[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [searchTerm, setSearchTerm] = React.useState('');
  const [selectedCategory, setSelectedCategory] = React.useState<string>('');
  const [selectedSubcategory, setSelectedSubcategory] = React.useState<string>('');

  // Get unique categories and subcategories
  const categories = React.useMemo(() => 
    Array.from(new Set(codes.map(code => code.category))).sort(),
    [codes]
  );

  const subcategories = React.useMemo(() => 
    Array.from(new Set(codes
      .filter(code => !selectedCategory || code.category === selectedCategory)
      .map(code => code.subcategory))).sort(),
    [codes, selectedCategory]
  );

  // Filter codes based on search and categories
  const filteredCodes = React.useMemo(() => 
    codes.filter(code => {
      const matchesSearch = searchTerm === '' || 
        code.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        code.code.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = !selectedCategory || code.category === selectedCategory;
      const matchesSubcategory = !selectedSubcategory || code.subcategory === selectedSubcategory;
      return matchesSearch && matchesCategory && matchesSubcategory;
    }),
    [codes, searchTerm, selectedCategory, selectedSubcategory]
  );

  // Fetch codes from Supabase
  React.useEffect(() => {
    async function fetchCodes() {
      try {
        const { data, error } = await supabase
          .from('ark_codes')
          .select('*')
          .order('category')
          .order('subcategory')
          .order('title');

        if (error) throw error;
        setCodes(data || []);
      } catch (error) {
        console.error('Error fetching codes:', error);
        toast.error('載入代碼失敗');
      } finally {
        setLoading(false);
      }
    }

    fetchCodes();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-gray-600 dark:text-gray-300">載入中...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-4 md:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4 md:mb-0">
            LY方舟複製
          </h1>
          
          {/* Search Bar */}
          <div className="w-full md:w-96 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="搜尋代碼..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4 mb-6">
          <select
            value={selectedCategory}
            onChange={(e) => {
              setSelectedCategory(e.target.value);
              setSelectedSubcategory('');
            }}
            className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">所有類別</option>
            {categories.map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>

          <select
            value={selectedSubcategory}
            onChange={(e) => setSelectedSubcategory(e.target.value)}
            className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">所有子類別</option>
            {subcategories.map(subcategory => (
              <option key={subcategory} value={subcategory}>{subcategory}</option>
            ))}
          </select>
        </div>

        {/* Code Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCodes.map((code) => (
            <div
              key={code.id}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
            >
              <div className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                    {code.title}
                  </h3>
                  <CopyToClipboard 
                    text={code.code}
                    onCopy={() => toast.success('代碼已複製！')}
                  >
                    <button className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded">
                      <Copy className="h-5 w-5 text-gray-500 dark:text-gray-400" />
                    </button>
                  </CopyToClipboard>
                </div>
                <div className="flex gap-2 mb-3">
                  <span className="px-2 py-1 text-xs rounded-full bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200">
                    {code.category}
                  </span>
                  <span className="px-2 py-1 text-xs rounded-full bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">
                    {code.subcategory}
                  </span>
                </div>
                <pre className="bg-gray-50 dark:bg-gray-900 p-3 rounded-lg overflow-x-auto text-sm text-gray-800 dark:text-gray-200">
                  {code.code}
                </pre>
              </div>
            </div>
          ))}
        </div>

        {filteredCodes.length === 0 && (
          <div className="text-center py-12 text-gray-500 dark:text-gray-400">
            沒有找到相關代碼
          </div>
        )}
      </div>
    </div>
  );
}