import { create } from 'zustand'

interface SettingsState {
  isSettingsOpen: boolean
  toggleSettings: () => void
}

export const useSettingsStore = create<SettingsState>((set) => ({
  isSettingsOpen: false,
  toggleSettings: () => set((state) => ({ isSettingsOpen: !state.isSettingsOpen })),
}))