import { create } from 'zustand'
import { supabase } from '../lib/supabase'

interface AuthState {
  isAuthenticated: boolean
  user: any | null
  setUser: (user: any) => void
  signOut: () => Promise<void>
}

export const useAuthStore = create<AuthState>((set) => ({
  isAuthenticated: false,
  user: null,
  setUser: (user) => set({ user, isAuthenticated: !!user }),
  signOut: async () => {
    await supabase.auth.signOut()
    set({ user: null, isAuthenticated: false })
  },
}))