import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  'zh-TW': {
    translation: {
      'login.title': '登入',
      'login.email': '電子郵件',
      'login.password': '密碼',
      'login.submit': '登入',
      'login.register': '註冊',
      'settings.title': '設定',
      'settings.theme': '主題',
      'settings.language': '語言',
      'settings.theme.light': '淺色',
      'settings.theme.dark': '深色',
      'settings.language.zh-TW': '繁體中文',
      'settings.language.zh-CN': '简体中文',
      'auth.login.success': '登入成功！',
      'auth.register.success': '註冊成功！',
      'auth.error': '發生錯誤',
      'social.login.developing': '社交登入功能正在開發中',
    },
  },
  'zh-CN': {
    translation: {
      'login.title': '登录',
      'login.email': '电子邮件',
      'login.password': '密码',
      'login.submit': '登录',
      'login.register': '注册',
      'settings.title': '设置',
      'settings.theme': '主题',
      'settings.language': '语言',
      'settings.theme.light': '浅色',
      'settings.theme.dark': '深色',
      'settings.language.zh-TW': '繁体中文',
      'settings.language.zh-CN': '简体中文',
      'auth.login.success': '登录成功！',
      'auth.register.success': '注册成功！',
      'auth.error': '发生错误',
      'social.login.developing': '社交登录功能正在开发中',
    },
  },
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: localStorage.getItem('language') || 'zh-TW',
    fallbackLng: 'zh-TW',
    interpolation: {
      escapeValue: false,
    },
  });

export default i18n;