export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      ark_codes: {
        Row: {
          id: string
          title: string
          code: string
          category: string
          subcategory: string
          created_at: string
          updated_at: string
          user_id: string
        }
        Insert: {
          id?: string
          title: string
          code: string
          category: string
          subcategory: string
          created_at?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          id?: string
          title?: string
          code?: string
          category?: string
          subcategory?: string
          created_at?: string
          updated_at?: string
          user_id?: string
        }
      }
      user_preferences: {
        Row: {
          id: string
          user_id: string
          theme: 'light' | 'dark'
          language: 'zh-TW' | 'zh-CN'
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          theme?: 'light' | 'dark'
          language?: 'zh-TW' | 'zh-CN'
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          theme?: 'light' | 'dark'
          language?: 'zh-TW' | 'zh-CN'
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}