import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import { Settings, Info } from 'lucide-react';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import SettingsModal from './components/SettingsModal';
import AboutAuthor from './components/AboutAuthor';
import { useAuthStore } from './stores/authStore';
import { useSettingsStore } from './stores/settingsStore';

function App() {
  const { t } = useTranslation();
  const { isAuthenticated } = useAuthStore();
  const { isSettingsOpen, toggleSettings } = useSettingsStore();
  const [isAboutOpen, setIsAboutOpen] = React.useState(false);

  // Initialize theme from localStorage
  React.useEffect(() => {
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.classList.toggle('dark', savedTheme === 'dark');
  }, []);

  return (
    <Router>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
        <Routes>
          <Route path="/" element={isAuthenticated ? <Dashboard /> : <Login />} />
        </Routes>
        
        {/* Settings Button */}
        <button
          onClick={toggleSettings}
          className="fixed left-4 bottom-4 p-3 rounded-full bg-white dark:bg-gray-800 shadow-lg hover:shadow-xl transition-shadow"
          aria-label={t('settings.title')}
        >
          <Settings className="w-6 h-6 text-gray-600 dark:text-gray-300" />
        </button>

        {/* About Author Button */}
        <button
          onClick={() => setIsAboutOpen(true)}
          className="fixed right-4 top-4 p-3 rounded-full bg-white dark:bg-gray-800 shadow-lg hover:shadow-xl transition-shadow"
          aria-label="關於作者"
        >
          <Info className="w-6 h-6 text-gray-600 dark:text-gray-300" />
        </button>

        {/* Modals */}
        {isSettingsOpen && <SettingsModal />}
        <AboutAuthor isOpen={isAboutOpen} onClose={() => setIsAboutOpen(false)} />

        {/* Toast Container */}
        <Toaster position="top-right" />
      </div>
    </Router>
  );
}

export default App;