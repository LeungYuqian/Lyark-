import React from 'react';
import { useTranslation } from 'react-i18next';
import { X } from 'lucide-react';
import { useSettingsStore } from '../stores/settingsStore';

export default function SettingsModal() {
  const { t, i18n } = useTranslation();
  const { toggleSettings } = useSettingsStore();
  const [theme, setTheme] = React.useState(
    localStorage.getItem('theme') || 'light'
  );

  const handleThemeChange = (newTheme: string) => {
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
    document.documentElement.classList.toggle('dark', newTheme === 'dark');
  };

  const handleLanguageChange = (language: string) => {
    i18n.changeLanguage(language);
    localStorage.setItem('language', language);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 w-full max-w-md mx-4 relative">
        <button
          onClick={toggleSettings}
          className="absolute right-4 top-4 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
        >
          <X className="w-6 h-6" />
        </button>

        <h2 className="text-2xl font-semibold mb-6 text-gray-900 dark:text-white">
          {t('settings.title')}
        </h2>

        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-3">
              {t('settings.theme')}
            </h3>
            <div className="flex space-x-4">
              <button
                onClick={() => handleThemeChange('light')}
                className={`px-4 py-2 rounded-lg ${
                  theme === 'light'
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                }`}
              >
                {t('settings.theme.light')}
              </button>
              <button
                onClick={() => handleThemeChange('dark')}
                className={`px-4 py-2 rounded-lg ${
                  theme === 'dark'
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                }`}
              >
                {t('settings.theme.dark')}
              </button>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-3">
              {t('settings.language')}
            </h3>
            <div className="flex space-x-4">
              <button
                onClick={() => handleLanguageChange('zh-TW')}
                className={`px-4 py-2 rounded-lg ${
                  i18n.language === 'zh-TW'
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                }`}
              >
                {t('settings.language.zh-TW')}
              </button>
              <button
                onClick={() => handleLanguageChange('zh-CN')}
                className={`px-4 py-2 rounded-lg ${
                  i18n.language === 'zh-CN'
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                }`}
              >
                {t('settings.language.zh-CN')}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}