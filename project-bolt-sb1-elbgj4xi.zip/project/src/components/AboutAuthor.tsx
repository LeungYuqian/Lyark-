import React from 'react';
import { X } from 'lucide-react';

interface AboutAuthorProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AboutAuthor({ isOpen, onClose }: AboutAuthorProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 w-full max-w-md mx-4 relative">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
        >
          <X className="w-6 h-6" />
        </button>

        <h2 className="text-2xl font-semibold mb-6 text-gray-900 dark:text-white">
          關於作者
        </h2>

        <div className="space-y-4 text-gray-600 dark:text-gray-300">
          <div className="border-b border-gray-200 dark:border-gray-700 pb-4">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              作者資訊
            </h3>
            <p>作者：Ly謙謙</p>
            <p>徒弟：張魚</p>
            <p>快手號：3907512309</p>
          </div>

          <div className="border-b border-gray-200 dark:border-gray-700 pb-4">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              聯繫方式
            </h3>
            <p>QQ群：545199759</p>
          </div>

          <div>
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              版權聲明
            </h3>
            <p>本網站由Ly謙謙開發維護，版權所有</p>
            <p>方舟代碼僅供參考，實際內容以遊戲內為準</p>
          </div>
        </div>
      </div>
    </div>
  );
}