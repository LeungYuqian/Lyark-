/*
  # Initial Schema Setup for LY ARK Code Share

  1. New Tables
    - `ark_codes`
      - Stores all ARK game codes
      - Includes categorization and user ownership
    - `user_preferences`
      - Stores user preferences like theme and language
      - Links to Supabase auth users

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated access
*/

-- Create ark_codes table
CREATE TABLE IF NOT EXISTS ark_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  code text NOT NULL,
  category text NOT NULL,
  subcategory text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  user_id uuid REFERENCES auth.users(id)
);

-- Create user_preferences table
CREATE TABLE IF NOT EXISTS user_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) UNIQUE NOT NULL,
  theme text DEFAULT 'light' CHECK (theme IN ('light', 'dark')),
  language text DEFAULT 'zh-TW' CHECK (language IN ('zh-TW', 'zh-CN')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE ark_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_preferences ENABLE ROW LEVEL SECURITY;

-- Policies for ark_codes
CREATE POLICY "Anyone can read ark codes"
  ON ark_codes
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Users can insert their own codes"
  ON ark_codes
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own codes"
  ON ark_codes
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Policies for user_preferences
CREATE POLICY "Users can manage their own preferences"
  ON user_preferences
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);